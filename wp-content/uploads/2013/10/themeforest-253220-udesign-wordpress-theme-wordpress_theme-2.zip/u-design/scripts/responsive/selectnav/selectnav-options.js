selectnav('main-top-menu', {
    activeclass: 'current-menu-item',
    label: '--- Navigation --- ',
    indent: '--'
});